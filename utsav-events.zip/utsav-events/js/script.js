const EVENTS=[
 {id:1,name:"Odisha Dev Summit",cat:"Tech",date:"2026-11-21T10:00",venue:"KIIT Convention Centre",cap:300,taken:212,hue:[210,260],desc:"A full day of talks on web, cloud and open source from engineers across eastern India.",long:"Eight talks, two workshops and a career fair. Lunch and certificates are included for every attendee."},
 {id:2,name:"Rhythm of Utkal",cat:"Music",date:"2026-11-28T18:30",venue:"Rabindra Mandap",cap:500,taken:471,hue:[330,20],desc:"Odissi, folk and fusion acts share one stage for an evening of live music.",long:"Doors open at 5:30 PM. Three headline performances, a short interval and local street food at the venue."},
 {id:3,name:"Startup Pitch Night",cat:"Business",date:"2026-12-05T17:00",venue:"IIIT Bhubaneswar Auditorium",cap:150,taken:64,hue:[160,200],desc:"Ten early-stage founders pitch to a panel of investors. Audience votes for a favourite.",long:"Each founder gets five minutes and three minutes of questions. Networking tea follows the final pitch."},
 {id:4,name:"Kalinga 10K Run",cat:"Sports",date:"2026-12-13T05:30",venue:"Kalinga Stadium",cap:800,taken:390,hue:[20,50],desc:"A timed 10 km road run through the city’s tree-lined avenues, open to all fitness levels.",long:"Chip timing, hydration points every 2 km, a finisher medal and breakfast for all participants."},
 {id:5,name:"Pattachitra Workshop",cat:"Art",date:"2026-12-19T11:00",venue:"Odisha State Museum",cap:40,taken:33,hue:[0,40],desc:"Learn the basics of traditional scroll painting from award-winning artisans from Raghurajpur.",long:"All materials are provided. You will leave with a finished A4 painting. Beginners are welcome."},
 {id:6,name:"24-Hour AI Hackathon",cat:"Tech",date:"2027-01-09T09:00",venue:"Centurion University Campus",cap:200,taken:88,hue:[250,300],desc:"Form a team of up to four and build something useful with data and AI in one day.",long:"Mentors on site, meals and snacks provided. Prizes for the top three teams and a best-design award."}
];
const $=s=>document.querySelector(s), KEY="utsav.registrations";
let cat="All", q="", current=null;

/* storage */
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY))||[]}catch(e){return []}};
const save=a=>{try{localStorage.setItem(KEY,JSON.stringify(a))}catch(e){}};
const left=e=>e.cap-e.taken-load().filter(r=>r.eventId===e.id).length;
const fmt=(d,o)=>new Date(d).toLocaleDateString("en-IN",o);
const esc=s=>s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

/* theme */
function setTheme(t){document.documentElement.dataset.theme=t;$("#theme").textContent=t==="dark"?"☀":"☾";try{localStorage.setItem("utsav.theme",t)}catch(e){}}
let saved=null;try{saved=localStorage.getItem("utsav.theme")}catch(e){}
setTheme(saved||(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light"));
$("#theme").onclick=()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark");
$("#burger").onclick=e=>{const o=$("#menu").classList.toggle("open");e.currentTarget.setAttribute("aria-expanded",o)};
$("#menu").onclick=()=>$("#menu").classList.remove("open");

/* countdown */
const upcoming=()=>EVENTS.filter(e=>new Date(e.date)>new Date()).sort((a,b)=>new Date(a.date)-new Date(b.date));
function tick(){
  const n=upcoming()[0]; if(!n){$("#nextTitle").textContent="New events soon";$("#count").innerHTML="";return}
  $("#nextTitle").textContent=n.name;
  let s=Math.max(0,Math.floor((new Date(n.date)-new Date())/1000));
  const v=[["days",86400],["hours",3600],["mins",60],["secs",1]].map(([l,u])=>{const x=Math.floor(s/u);s-=x*u;return `<div><b>${String(x).padStart(2,"0")}</b><span>${l}</span></div>`});
  $("#count").innerHTML=v.join("");
}
tick();setInterval(tick,1000);

/* chips + grid */
const cats=["All",...new Set(EVENTS.map(e=>e.cat))];
$("#chips").innerHTML=cats.map(c=>`<button class="chip" aria-pressed="${c==="All"}">${c}</button>`).join("");
$("#chips").onclick=e=>{const b=e.target.closest(".chip");if(!b)return;cat=b.textContent;
  document.querySelectorAll(".chip").forEach(c=>c.setAttribute("aria-pressed",c===b));render()};
$("#search").oninput=e=>{q=e.target.value.trim().toLowerCase();render()};

function render(){
  const list=EVENTS.filter(e=>(cat==="All"||e.cat===cat)&&(e.name+e.venue+e.desc+e.cat).toLowerCase().includes(q));
  $("#grid").innerHTML=list.length?list.map(e=>{const l=left(e);return `
  <article class="card">
    <div class="art" style="background:linear-gradient(135deg,hsl(${e.hue[0]} 70% 45%),hsl(${e.hue[1]} 75% 35%))">
      <span class="tag">${e.cat}</span>
      <div class="date">${fmt(e.date,{day:"numeric"})}<small>${fmt(e.date,{month:"short"})}</small></div>
    </div>
    <div class="body">
      <h3>${e.name}</h3>
      <div class="venue">${e.venue} · ${fmt(e.date,{weekday:"short",hour:"numeric",minute:"2-digit"})}</div>
      <p class="desc">${e.desc}</p>
      <div class="foot"><span class="seats ${l<30?"low":""}">${l>0?l+" seats left":"Sold out"}</span>
      <button class="btn" data-id="${e.id}">View details</button></div>
    </div>
  </article>`}).join(""):`<p class="empty">No events match your search. Try another keyword or category.</p>`;
}
$("#grid").onclick=e=>{const b=e.target.closest("[data-id]");if(b)openModal(+b.dataset.id)};

/* modal + form */
function openModal(id){
  current=EVENTS.find(e=>e.id===id);const l=left(current);
  $("#modal").innerHTML=`
  <button class="icon-btn close" aria-label="Close" id="x">✕</button>
  <div class="info">
    <span class="seats">${current.cat}</span>
    <h2 id="mTitle">${current.name}</h2>
    <p>${current.long}</p>
    <dl><dt>Date</dt><dd>${fmt(current.date,{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</dd>
    <dt>Time</dt><dd>${fmt(current.date,{hour:"numeric",minute:"2-digit"}).split(", ").pop()}</dd>
    <dt>Venue</dt><dd>${current.venue}</dd><dt>Seats</dt><dd>${l} of ${current.cap} left</dd></dl>
  </div>
  ${l>0?`<form id="form" novalidate>
    <h3 style="margin-bottom:1rem">Register for this event</h3>
    <div class="field"><label for="n">Full name</label><input id="n" autocomplete="name"><div class="err"></div></div>
    <div class="field"><label for="m">Email address</label><input id="m" type="email" autocomplete="email"><div class="err"></div></div>
    <div class="field"><label for="p">Phone number</label><input id="p" type="tel" inputmode="numeric" placeholder="10-digit mobile number" autocomplete="tel"><div class="err"></div></div>
    <div class="field"><label for="ev">Event</label><select id="ev">${EVENTS.map(e=>`<option value="${e.id}" ${e.id===id?"selected":""}>${e.name}</option>`).join("")}</select></div>
    <button class="btn" style="width:100%">Confirm registration</button>
  </form>`:`<div class="done"><h3>This event is sold out</h3><p>Check other events or come back later in case seats open up.</p></div>`}`;
  $("#overlay").classList.add("open");document.body.style.overflow="hidden";
  $("#x").onclick=closeModal;$("#x").focus();
  const f=$("#form");if(f)f.onsubmit=submit;
}
function closeModal(){$("#overlay").classList.remove("open");document.body.style.overflow=""}
$("#overlay").onclick=e=>{if(e.target.id==="overlay")closeModal()};
addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

const rules={
  n:v=>/^[A-Za-z][A-Za-z .'-]{1,49}$/.test(v)?"":"Enter your full name using letters only (at least 2).",
  m:v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)?"":"Enter a valid email, like name@example.com.",
  p:v=>/^[6-9]\d{9}$/.test(v.replace(/[\s-]/g,""))?"":"Enter a 10-digit Indian mobile number starting with 6–9."
};
function check(k){const i=$("#"+k),m=rules[k](i.value.trim());i.classList.toggle("bad",!!m);i.nextElementSibling.textContent=m;return !m}
document.addEventListener("input",e=>{if(rules[e.target.id]&&e.target.classList.contains("bad"))check(e.target.id)});
document.addEventListener("focusout",e=>{if(rules[e.target.id]&&e.target.value)check(e.target.id)});

function submit(e){
  e.preventDefault();
  const ok=Object.keys(rules).map(check).every(Boolean);
  if(!ok){document.querySelector(".bad").focus();return}
  const ev=EVENTS.find(x=>x.id===+$("#ev").value);
  if(left(ev)<1){alert("Sorry, that event just sold out.");return}
  const all=load(), email=$("#m").value.trim().toLowerCase();
  if(all.some(r=>r.eventId===ev.id&&r.email===email)){
    const s=$("#m");s.classList.add("bad");s.nextElementSibling.textContent="This email is already registered for "+ev.name+".";s.focus();return}
  const rec={ref:"UT"+Date.now().toString(36).toUpperCase(),eventId:ev.id,name:$("#n").value.trim(),email,phone:$("#p").value.replace(/[\s-]/g,"")};
  all.push(rec);save(all);
  $("#form").outerHTML=`<div class="done"><div class="tick">✓</div><h3>You’re registered, ${esc(rec.name.split(" ")[0])}!</h3>
  <p>${ev.name} on ${fmt(ev.date,{day:"numeric",month:"long"})}. We’ve saved your booking, reference <b>${rec.ref}</b>.</p>
  <button class="btn" id="ok">Done</button></div>`;
  $("#ok").onclick=closeModal;$("#ok").focus();
  render();renderRegs();
}

/* registrations */
function renderRegs(){
  const a=load();
  $("#regs").innerHTML=a.length?a.map(r=>{const e=EVENTS.find(x=>x.id===r.eventId);return `
  <div class="reg"><div><b>${e.name}</b><br><small>${esc(r.name)} · ${esc(r.email)} · ${fmt(e.date,{day:"numeric",month:"short",year:"numeric"})} · Ref ${r.ref}</small></div>
  <button data-cancel="${r.ref}">Cancel registration</button></div>`}).join(""):`<p class="empty" style="padding:1rem 0;text-align:left">You haven’t registered for anything yet. Pick an event above to get started.</p>`;
}
$("#regs").onclick=e=>{const r=e.target.dataset.cancel;if(r&&confirm("Cancel this registration?")){save(load().filter(x=>x.ref!==r));render();renderRegs()}};

render();renderRegs();
