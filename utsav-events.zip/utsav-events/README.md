# Utsav – Event Management Website

A responsive event management website where users can explore upcoming events in Bhubaneswar, search and filter them, view details and register. Built with **HTML5, CSS3 and vanilla JavaScript** (no frameworks or build step).

**Live demo:** `https://<your-username>.github.io/utsav-events/` *(replace after deploying)*

## Features

- **Hero section** with a live countdown to the next upcoming event
- **Event cards** showing category, date, venue, short description and seats left
- **Search** by name, venue or keyword, combined with **category filters**
- **Event details modal** with full description, schedule and registration form
- **Form validation** in JavaScript:
  - Name: letters only, 2–50 characters
  - Email: valid format
  - Phone: 10-digit Indian mobile number (starts with 6–9)
  - Duplicate registrations for the same event and email are blocked
- **Confirmation screen** with a unique booking reference after successful registration
- **Local Storage** for registrations, with a *My registrations* section where bookings can be cancelled; seat counts update automatically
- **Dark / light mode** that follows system preference and remembers the user's choice
- **Fully responsive** layout for mobile, tablet and desktop, including a collapsible mobile menu
- **Accessibility:** semantic HTML, ARIA labels, visible keyboard focus, `Esc` to close the modal, reduced-motion support

## Tech stack

| Area | Technology |
|------|------------|
| Structure | HTML5 |
| Styling | CSS3 (custom properties, Grid, Flexbox, media queries) |
| Logic | Vanilla JavaScript (ES6) |
| Storage | Browser Local Storage |
| Fonts | Google Fonts (Bricolage Grotesque, DM Sans) |
| Version control | Git and GitHub |

## Project structure

```
utsav-events/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── README.md
└── .gitignore
```

## Run locally

```bash
git clone https://github.com/<your-username>/utsav-events.git
cd utsav-events
# open index.html in a browser, or serve it:
python3 -m http.server 8000   # then visit http://localhost:8000
```

## Deployment (GitHub Pages)

1. Push the project to GitHub.
2. Go to **Settings → Pages**.
3. Under *Source*, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. After a minute, the site is live at `https://<your-username>.github.io/utsav-events/`.

## How it works

- Events are stored in an `EVENTS` array at the top of `js/script.js`. Add or edit objects there to change the listings.
- Registrations are saved under the `utsav.registrations` key in Local Storage; the theme is saved under `utsav.theme`.
- Seats left = capacity − pre-booked seats − registrations made in this browser.

## Screenshots

*Add screenshots here after running the project:*

| Home | Event details | Mobile |
|------|---------------|--------|
| `screenshots/home.png` | `screenshots/modal.png` | `screenshots/mobile.png` |

## Possible improvements

- Backend and database for shared registrations
- Email confirmations
- Calendar (.ics) download
- Admin page for creating events

## Author

**<Your Name>** · Roll No. <Your Roll No.> · <Your Section>

## License

Released under the MIT License.
